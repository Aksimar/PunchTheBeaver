﻿using PunchTheBeaver.Forms;
using PunchTheBeaver.Gameplay;
using System;
using System.Windows.Forms;

namespace PunchTheBeaver
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainMenu());
        }


      











    }
}
